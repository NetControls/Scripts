﻿/*This script demonstrates sending of user input*/

//Is called if this script shall be exited.
function stopScript() 
{
	scriptThread.setMainWindowAndTaskBarIcon("default.ico");
    scriptThread.appendTextToConsole("script has been stopped");
}

//The dialog is closed.
function dialogFinished(e)
{
	scriptThread.stopScript()
}
//Send Postion Functions 1-4
function sendP1()
{
	haltPoll();
	if(axisInit_1 != 1){
		scriptThread.messageBox("Critical", "Error", "AXIS 1 WAS NOT INITIALIZED!");
		return;
		}
	var stepsToSend = parseFloat(UI_linePos_1.text());
	stepsToSend *= stepsPerUnit_1;
	stepsToSend += stepsOffset_1;
	var stepInt = Math.round(stepsToSend);
	var data = ":1p";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);		
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}

function sendP2()
{
	haltPoll();
	if(axisInit_2 != 1){
		scriptThread.messageBox("Critical", "Error", "AXIS 2 WAS NOT INITIALIZED!");
		return;
		}
	var stepsToSend = parseFloat(UI_linePos_2.text());
	stepsToSend *= stepsPerUnit_2;
	stepsToSend += stepsOffset_2;
	var stepInt = Math.round(stepsToSend);	
	var data = ":2p";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}

function sendP3()
{
	haltPoll();
	if(axisInit_3 != 1){
		scriptThread.messageBox("Critical", "Error", "AXIS 3 WAS NOT INITIALIZED!");
		return;
		}
	var stepsToSend = parseFloat(UI_linePos_3.text());
	stepsToSend *= stepsPerUnit_3;
	stepsToSend += stepsOffset_3;
	var stepInt = Math.round(stepsToSend);
	var data = ":3p";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);			
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}

function sendP4()
{
	haltPoll();
	if(axisInit_4 != 1){
		scriptThread.messageBox("Critical", "Error", "AXIS 4 WAS NOT INITIALIZED!");
		return;
		}
	var stepsToSend = parseFloat(UI_linePos_4.text());
	stepsToSend *= stepsPerUnit_4;
	stepsToSend += stepsOffset_4;
	var stepInt = Math.round(stepsToSend);
	var data = ":4p";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);			
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}

//Send Halt Functions 1-4
function sendH1(){
	haltPoll();
	var data = ":1h1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendH2(){
	haltPoll();
	var data = ":2h1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendH3(){
	haltPoll();
	var data = ":3h1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendH4(){
	haltPoll();
	var data = ":4h1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
//Stop All Motors
function sendHAll(){
	haltPoll();
	var data = ":0h1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}

//Send Init Functions 1-4
function sendI1(){
	haltPoll();
	var data = ":1i1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
	else{
		axisInit_1 = 1;
		}
}
function sendI2(){
	haltPoll();
	var data = ":2i1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
	else{
		axisInit_2 = 1;
		}
}
function sendI3(){
	haltPoll();
	var data = ":3i1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
	else{
		axisInit_3 = 1;
		}
}
function sendI4(){
	haltPoll();
	var data = ":4i1\r";
	UI_textConsole.append(data);	
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
	else{
		axisInit_4 = 1;
		}
}

//----------------------------------------------------------------------------------
//Send Speed Functions 1-4
function sendS1()
{
	haltPoll();
	var speedToSend = parseFloat(UI_lineSpeed_1.text());
	//First Convert to SPS
	speedToSend *= stepsPerUnit_1;
	//Then convert to SPM
	speedToSend /= 60;	
	var stepInt = Math.round(speedToSend);		
	var data = ":1v";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);		
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendS2()
{
	haltPoll();
	var speedToSend = parseFloat(UI_lineSpeed_2.text());
	//First Convert to SPS
	speedToSend *= stepsPerUnit_2;
	//Then convert to SPM
	speedToSend /= 60;
	var stepInt = Math.round(speedToSend);
	var data = ":2v";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);		
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendS3()
{
	haltPoll();
	var speedToSend = parseFloat(UI_lineSpeed_3.text());
	//First Convert to SPS
	speedToSend *= stepsPerUnit_3;
	//Then convert to SPM
	speedToSend /= 60;
	var stepInt = Math.round(speedToSend);
	var data = ":3v";
	data += stepInt.toString();
	data += "\r";
	UI_textConsole.append(data);		
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
function sendS4()
{
	haltPoll();
	var speedToSend = parseInt(UI_lineSpeed_4.text());
	UI_textConsole.append(speedToSend);
	var data = ":4v";
	data += speedToSend.toString();
	data += "\r";
	UI_textConsole.append(data);		
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
}
//----------------------------------------------------------------------------------
//----------------------------------------------------------------------------------



//Called by timer (Currently at 1 second)
function timerSlot()
{
	var data = ":";
	data += axisToSend.toString();
	data += "p\r";	
	axisToSend += 1;	
	if(axisToSend > 4){
		axisToSend = 1;
		}			
	UI_textConsole.append("Data Sent to Axis: " + data);
	if(!scriptInf.sendString(data))
		{
		scriptThread.messageBox("Critical", "Error", "Sending failed. Check if ScriptCommunicator is connected.");
		}
	messageOutstanding = 1;
}
function parseData()
{
	var data = receivedData[1];
	var cmd = receivedData[2];
		
	receivedData.shift();//shift out the :
	receivedData.shift();//shfit out the axis number
	receivedData.shift();//shfit out the command
	//----------Save this...this is how you convert a number to a string...
	//stringData = data.toString();
	//UI_lineDisplay_4.setText(stringData);
	if (cmd == 112){
		if(data == 49){
			UI_lineDisplay_1.clear();
			var floatValue = parseFloat(conv.byteArrayToString(receivedData));
			UI_textConsole.append("Data Received from Axis 1: " + floatValue);
			floatValue = (floatValue - stepsOffset_1) / stepsPerUnit_1;
			UI_lineDisplay_1.setText(floatValue.toFixed(4));			
			}
		else if(data == 50){
			UI_lineDisplay_2.clear();
			var floatValue = parseFloat(conv.byteArrayToString(receivedData));
			UI_textConsole.append("Data Received from Axis 2: " + floatValue);
			floatValue = (floatValue - stepsOffset_2) / stepsPerUnit_2;
			UI_lineDisplay_2.setText(floatValue.toFixed(4));	
			}
		else if(data == 51){
			UI_lineDisplay_3.clear();
			var floatValue = parseFloat(conv.byteArrayToString(receivedData));
			UI_textConsole.append("Data Received from Axis 3: " + floatValue);
			floatValue = (floatValue - stepsOffset_3) / stepsPerUnit_3;
			UI_lineDisplay_3.setText(floatValue.toFixed(4));	
			}
		else if(data == 52){
			UI_lineDisplay_4.clear();
			var floatValue = parseFloat(conv.byteArrayToString(receivedData));
			UI_textConsole.append("Data Received from Axis 4: " + floatValue);
			floatValue = (floatValue - stepsOffset_4) / stepsPerUnit_4;
			UI_lineDisplay_4.setText(floatValue.toFixed(4));	
			}
	}
	receivedData.length = 0;
}
//------------------------------------------------------------------
function dataReceivedSlot(data)
{
	var j = 0;	
	for(var i = 0; i < data.length; i++)
			{
			receivedData.push(data[i]);
			if(data[i] == 13)
				j = 1;
			}	
	if(j == 1)
			{
			messageOutstanding = 0;
			parseData();
			}	
}
//------------------------------------------------------------------

function startPoll(){
	timer.start(250);//timer interval= 250ms
}
function haltPoll(){
	timer.stop();
	if(messageOutstanding == 1){	
			var timeout = 50;
			UI_textConsole.append("Wating for message");
			while(messageOutstanding == 1){
				scriptThread.sleepFromScript(1);
				timeout--;
				if(timeout <=0){
					scriptThread.messageBox("Critical", "Error", "Sending failed. Communication Error.");
					}
				}
		}
}
function setStepsPer(){
	stepsPerUnit_1 = parseInt(UI_lineTPI_1.text());
	stepsPerUnit_2 = parseInt(UI_lineTPI_2.text());
	stepsPerUnit_3 = parseInt(UI_lineTPI_3.text());
	stepsPerUnit_4 = parseInt(UI_lineTPI_4.text());
	UI_textConsole.append(stepsPerUnit_1);
	UI_textConsole.append(stepsPerUnit_2);
	UI_textConsole.append(stepsPerUnit_3);
	UI_textConsole.append(stepsPerUnit_4);
	//Go ahead and send motor velocity setting with a single button click
	sendS1();
	sendS2();
	sendS3();
	sendS4();
}

function setOffset(){
	stepsOffset_1 = parseInt(UI_lineOff_1.text());
	stepsOffset_2 = parseInt(UI_lineOff_2.text());
	stepsOffset_3 = parseInt(UI_lineOff_3.text());
	stepsOffset_4 = parseInt(UI_lineOff_4.text());
	UI_textConsole.append(stepsOffset_1);
	UI_textConsole.append(stepsOffset_2);
	UI_textConsole.append(stepsOffset_3);
	UI_textConsole.append(stepsOffset_4);	
}

scriptThread.appendTextToConsole('script has started');
UI_Dialog.finishedSignal.connect(dialogFinished);

//--------------------------------------------------------
//--------Send Position Buttons----------------------
UI_SendPos_1.clickedSignal.connect(UI_SendPos_1, sendP1)
UI_SendPos_2.clickedSignal.connect(UI_SendPos_2, sendP2)
UI_SendPos_3.clickedSignal.connect(UI_SendPos_3, sendP3)
UI_SendPos_4.clickedSignal.connect(UI_SendPos_4, sendP4)
//---------------------------------------------------------

//--------------------------------------------------------
//--------Send Halt Buttons----------------------
UI_SendStop_1.clickedSignal.connect(UI_SendStop_1, sendH1)
UI_SendStop_2.clickedSignal.connect(UI_SendStop_2, sendH2)
UI_SendStop_3.clickedSignal.connect(UI_SendStop_3, sendH3)
UI_SendStop_4.clickedSignal.connect(UI_SendStop_4, sendH4)
UI_SendStopAll.clickedSignal.connect(UI_SendStopAll, sendHAll)
//---------------------------------------------------------

//--------------------------------------------------------
//--------Send Init Buttons----------------------
UI_SendInt_1.clickedSignal.connect(UI_SendInt_1, sendI1)
UI_SendInt_2.clickedSignal.connect(UI_SendInt_2, sendI2)
UI_SendInt_3.clickedSignal.connect(UI_SendInt_3, sendI3)
UI_SendInt_4.clickedSignal.connect(UI_SendInt_4, sendI4)
//---------------------------------------------------------

//--------------------------------------------------------
//--------Send Speed Buttons-----------------------
UI_SendSpeed_1.clickedSignal.connect(UI_SendSpeed_1, sendS1)
UI_SendSpeed_2.clickedSignal.connect(UI_SendSpeed_2, sendS2)
UI_SendSpeed_3.clickedSignal.connect(UI_SendSpeed_3, sendS3)
UI_SendSpeed_4.clickedSignal.connect(UI_SendSpeed_4, sendS4)
//---------------------------------------------------------

UI_StartPoll.clickedSignal.connect(UI_StartPoll, startPoll)
UI_haltPoll.clickedSignal.connect(UI_haltPoll, haltPoll)
UI_setStepSize.clickedSignal.connect(UI_setStepSize, setStepsPer)
UI_setOffsets.clickedSignal.connect(UI_setOffsets, setOffset)
//scriptThread.appendTextToConsole("serial port signals: " + scriptInf.getSerialPortSignals().toString(16));
scriptThread.setMainWindowAndTaskBarIcon("mainWindowIcon.ico");
UI_Dialog.setWindowIcon("dialogIcon.png");

//--------------------------------------------
var messageOutstanding = 0;
var axisToSend = 1;
var axisInit_1 = 0;
var axisInit_2 = 0;
var axisInit_3 = 0;
var axisInit_4 = 0;
var receivedData = Array();
var stepsPerUnit_1 = parseInt(UI_lineTPI_1.text());
var stepsPerUnit_2 = parseInt(UI_lineTPI_2.text());
var stepsPerUnit_3 = parseInt(UI_lineTPI_3.text());
var stepsPerUnit_4 = parseInt(UI_lineTPI_4.text());
//----Add Offsets----------
var stepsOffset_1 = 0;
var stepsOffset_2 = 0;
var stepsOffset_3 =0;
var stepsOffset_4 = 0;
scriptInf.dataReceivedSignal.connect(dataReceivedSlot);
//--------------------------------------------

//Create, start and connect the send timer.
var timer = scriptThread.createTimer();
timer.timeoutSignal.connect(eval("timerSlot"));

